//
//  Photomemo+CoreDataClass.swift
//  MemoWithCollectionView
//
//  Created by 한병두 on 2018. 6. 22..
//  Copyright © 2018년 Byungdoo Han. All rights reserved.
//
//

import Foundation
import CoreData

@objc(Photomemo)
public class Photomemo: NSManagedObject {
    


}
